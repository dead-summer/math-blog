# Tinymist Coverage Report

| File | Executed | Not Executed | Total | Coverage |
|------|--------|--------|------|--------|
| html.typ | 0 | 138 | 138 | 0% |
| indentation.typ | 44 | 12 | 56 | 78.57% |
| lib.typ | 0 | 0 | 0 | 0.00% |
| mod.typ | 119 | 2 | 121 | 98.34% |
| state.typ | 68 | 6 | 74 | 91.89% |
| theme.typ | 0 | 0 | 0 | 0.00% |
| util.typ | 96 | 16 | 112 | 85.71% |
| README.typ | 11 | 15 | 26 | 42.30% |

## Overall Coverage: 64.13%

**Total:** 338 executed, 189 not executed, 527 total items

Last updated: 2025-04-29 03:42:20
